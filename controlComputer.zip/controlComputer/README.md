# controlComputer
By: Adam Li

This project uses objective-c and swift to create a command-line tool for reading in serial input and output keyboard strokes as a result. This project will be used correspondingly with a controller that can print to serial port.

To run:
  1. Run the project
  2. Select the serial port you want to use (see instructions when you run)
  3. If you mess up, restart
  4. Open up serial monitor (e.g. on Arduino)
  5. See it run!
